﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace пр16
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void TextForm2_Load(object sender, EventArgs e)
        {
            toolStripComboBox1.SelectedIndex = 0;
        }
        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged_1(object sender, EventArgs e)
        {

        }
        private void TextEditForm_Load(object sender, EventArgs e)
        {
            toolStripComboBox1.SelectedIndex = 0;
        }
        
        private void toolStripComboBox1_Click(object sender, EventArgs e)
        {

        }
        private void toolStripComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Font new1, old1;
            old1 = richTextBox1.Font;
            new1 = new Font(FontFamily.GenericSansSerif, float.Parse(toolStripComboBox1.Text.Trim()), old1.Style);
            richTextBox1.Font = new1;
        }

        private void жирныйToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            if (жирныйToolStripMenuItem.Checked)
                жирныйToolStripMenuItem.Checked = false;
            else
                жирныйToolStripMenuItem.Checked = true;
            Font new1, old1;
            old1 = richTextBox1.Font;
            if (old1.Bold)
                new1 = new Font(old1, old1.Style & ~FontStyle.Bold);
            else
                new1 = new Font(old1, old1.Style | FontStyle.Bold);

            richTextBox1.Font = new1;
            richTextBox1.Focus();
        }

        private void курсивToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (курсивToolStripMenuItem.Checked)
                курсивToolStripMenuItem.Checked = false;
            else
                курсивToolStripMenuItem.Checked = true;
            Font new1, old1;
            old1 = richTextBox1.Font;
            if (old1.Italic)
                new1 = new Font(old1, old1.Style & ~FontStyle.Italic);
            else
                new1 = new Font(old1, old1.Style | FontStyle.Italic);

            richTextBox1.Font = new1;
            richTextBox1.Focus();
        }

        private void подчёркнутыйToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (подчёркнутыйToolStripMenuItem.Checked)
                подчёркнутыйToolStripMenuItem.Checked = false;
            else
                подчёркнутыйToolStripMenuItem.Checked = true;
            Font new1, old1;
            old1 = richTextBox1.Font;
            if (old1.Underline)
                new1 = new Font(old1, old1.Style & ~FontStyle.Underline);
            else
                new1 = new Font(old1, old1.Style | FontStyle.Underline);

            richTextBox1.Font = new1;
            richTextBox1.Focus();
        }
    }
}
