﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace пр16
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            openFileDialog1.Filter = "Text files(*.txt)|*.txt|All files(*.*)|*.*";
            saveFileDialog1.Filter = "Text files(*.txt)|*.txt|All files(*.*)|*.*";
        }

        private void CreateForm2()
        {
            Form2 text = new Form2();
            text.MdiParent = this;
            text.Show();
            text.Text = "file.txt";
        }
        private void SaveFile()
        {
            Form2 child = ((Form2)this.ActiveMdiChild);
            string filename = child.Text;

            if (!filename.Contains("\\"))
            {
                SaveAs();
                return;
            }
            File.WriteAllText(filename, child.richTextBox1.Text);

            MessageBox.Show("Файл сохранен!");
            //this.ActiveMdiChild
        }

        private void SaveAs()
        {
            Form2 child = ((Form2)this.ActiveMdiChild);
            saveFileDialog1.FileName = child.Text;
            if (saveFileDialog1.ShowDialog() == DialogResult.Cancel)
                return;
            string text = child.richTextBox1.Text;


            StreamWriter streamWriter = new StreamWriter(saveFileDialog1.FileName);
            streamWriter.Write(text);
            streamWriter.Close();
            child.Text = saveFileDialog1.FileName;
            MessageBox.Show("Файл сохранен!");
        }
        private void OpenFile()
        {
            if (openFileDialog1.ShowDialog() == DialogResult.Cancel)
                return;

            string filename = openFileDialog1.FileName;

            if (this.ActiveMdiChild == null)
            {
                CreateForm2();
            }
            string fileText = System.IO.File.ReadAllText(filename);
            Form2 child = ((Form2)this.ActiveMdiChild);
            child.richTextBox1.Text = fileText;
            child.Text = filename;
        }

        private void toolStripButton1_Click(object sender, EventArgs e) // создать
        {
            CreateForm2();
        }

        private void toolStripButton2_Click(object sender, EventArgs e) // открыть
        {
            OpenFile();
        }


        private void toolStripButton5_Click(object sender, EventArgs e) // копировать
        {
            Form activeChild = this.ActiveMdiChild;
            if (activeChild != null)
            {
                RichTextBox editBox = (RichTextBox)activeChild.ActiveControl;
                if (editBox != null)
                {
                    Clipboard.SetDataObject(editBox.SelectedText);
                }
            }

        }

        private void toolStripButton6_Click(object sender, EventArgs e) // вставить
        {
            Form activeChild = this.ActiveMdiChild;
            if (activeChild != null)
            {
                RichTextBox editBox = (RichTextBox)activeChild.ActiveControl;
                if (editBox != null)
                {
                    IDataObject data = Clipboard.GetDataObject();
                    if (data.GetDataPresent(DataFormats.Text))
                    {
                        editBox.SelectedText =
                        data.GetData(DataFormats.Text).ToString();
                    }
                }
            }
        }

        private void toolStripButton4_Click(object sender, EventArgs e) // вырезать
        {
            Form2 activeChild = (Form2)this.ActiveMdiChild;
            if (activeChild != null)
            {
                RichTextBox editBox = (RichTextBox)activeChild.ActiveControl;
                if (editBox != null)
                {
                    Clipboard.SetDataObject(editBox.SelectedText);
                }
                activeChild.richTextBox1.SelectedText = "";
            }
            
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            SaveFile();
        }

        private void сохранитьКакToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveAs();
        }

        private void сохранитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFile();
        }

        private void открытьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFile();
        }

        private void создатьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CreateForm2();
        }
        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ActiveMdiChild.Close();
        }
    }
}
