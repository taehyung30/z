﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Drawing.Drawing2D;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            Graphics i = pictureBox2.CreateGraphics();
            i.Clear(Color.Yellow);
            SolidBrush hands = new SolidBrush(Color.DarkOliveGreen);
            SolidBrush white = new SolidBrush(Color.White);
            SolidBrush eyes = new SolidBrush(Color.DarkOliveGreen);
            LinearGradientBrush gradBrush = new LinearGradientBrush(new Rectangle(193, 146, 100, 90), 
                Color.LightGreen, Color.MintCream, LinearGradientMode.Vertical);
            SolidBrush body = new SolidBrush(Color.LightGreen);
            SolidBrush cheeks = new SolidBrush(Color.MistyRose);
            Pen draw = new Pen(Color.Black, 2);
            i.FillEllipse(body, 170, 90, 150, 146);
            i.FillEllipse(body, 173, 85, 50, 52);
            i.FillEllipse(body, 267, 85, 50, 52);
            i.FillEllipse(body, 193, 190, 30, 52);
            i.FillEllipse(body, 260, 190, 30, 52);
            i.FillEllipse(white, 285, 95, 23, 20);
            i.FillEllipse(eyes, 285, 95, 18, 20);
            i.FillEllipse(white, 185, 95, 23, 20);
            i.FillEllipse(eyes, 185, 95, 18, 20);
            i.FillEllipse(cheeks, 183, 120, 30, 25);
            i.FillEllipse(cheeks, 277, 120, 30, 25);
            i.FillEllipse(gradBrush, 193, 146, 100, 90);
            i.FillEllipse(hands, 200, 150, 25, 35);
            i.FillEllipse(hands, 260, 150, 25, 35);
            Pen draws = new Pen(Color.DarkOliveGreen, 2);
            Point start = new Point(240, 100);
            Point control1 = new Point(245, 110);
            Point control2 = new Point(245, 110);
            Point finish = new Point(250, 100);
            i.DrawBezier(draws, start, control1, control2, finish);
        }
        private void pictureBox2_Click(object sender, EventArgs e)
        {
        }
    }
}
