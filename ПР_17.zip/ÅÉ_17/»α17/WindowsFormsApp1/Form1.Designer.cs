﻿
namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.Нарисовать = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // Нарисовать
            // 
            this.Нарисовать.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Нарисовать.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Нарисовать.Font = new System.Drawing.Font("Mistral", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Нарисовать.ForeColor = System.Drawing.Color.Black;
            this.Нарисовать.Location = new System.Drawing.Point(166, 284);
            this.Нарисовать.Name = "Нарисовать";
            this.Нарисовать.Size = new System.Drawing.Size(127, 32);
            this.Нарисовать.TabIndex = 0;
            this.Нарисовать.Text = "Нарисовать";
            this.Нарисовать.UseVisualStyleBackColor = false;
            this.Нарисовать.Click += new System.EventHandler(this.button2_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(12, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(455, 266);
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(479, 319);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.Нарисовать);
            this.Name = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button Нарисовать;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}

