﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace пр18
{
    public partial class Form1: Form
    {
        private int startX, startY;
        Bitmap pic, pic2;
        int x1, y1;
        bool isLine, isCirle, isRectangle, drawing, isErase;
        public Form1()
        {
            InitializeComponent();
            pic = new Bitmap(1000, 1000);
            pic2 = new Bitmap(1000, 1000);
            x1 = y1 = 0;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
        }
        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            Graphics Graph1 = e.Graphics;
        }
        private void buttonBlue_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            label1.BackColor = b.BackColor;
            isErase = false;
        }
        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            if (isErase)
            {
                isErase = false;
            }
            else
            {
                isErase = true;
                label1.BackColor = pictureBox1.BackColor;
                
            }
        }
        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            if (isRectangle)
            {
                isRectangle = false;
            }
            else
            {
                isRectangle = true;
                isCirle = false;
                isLine = false;
            }
        }
        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            if (isLine)
            {
                isLine = false;
            }
            else
            {
                isLine = true;
                isCirle = false;
                isRectangle = false;
            }

        }
        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            if (isCirle)
            {
                isCirle = false;
            }
            else
            {
                isLine = false;
                isCirle = true;
                isRectangle = false;
            }

        }
        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            var pen = new Pen(label1.BackColor, trackBar1.Value);
            var g = Graphics.FromImage(pic);
            if (isLine)
            {
                var finish = new Point(e.X, e.Y);
                g.DrawLine(pen, new Point(startX, startY), finish);
                g.Save();
                drawing = false;
                g.Dispose();
                pictureBox1.Invalidate();
            }
            else if (isCirle)
            {
               g.DrawEllipse(pen, startX, startY, e.X - startX, e.Y - startY);
            }
            else if (isRectangle)
            {
                g.DrawRectangle(pen, startX, startY, e.X - startX, e.Y - startY);
            }
            
        }
        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {

            startX = e.X;
            startY = e.Y;
            drawing = true;

        }
        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            var p = new Pen(label1.BackColor, trackBar1.Value);
            

            if (drawing)
            {
                var gr = Graphics.FromImage(pic2);
                
                if (isLine)
                {

                    var finish = new Point(e.X, e.Y);
                    gr.DrawLine(p, new Point(startX, startY), finish);
                    gr.Dispose();
                    pictureBox1.Invalidate();
                    return;
                }
                else if (isCirle)
                {
                    gr.DrawEllipse(p, startX, startY, e.X - startX, e.Y - startY);
                }
                else if (isRectangle)
                {    
                    gr.DrawRectangle(p, startX, startY, e.X - startX, e.Y - startY);
                }
                
                
            }

            p.EndCap = System.Drawing.Drawing2D.LineCap.Round;
            p.StartCap = System.Drawing.Drawing2D.LineCap.Round;

            Graphics g;
            g = Graphics.FromImage(pic);

            if (e.Button == MouseButtons.Left)
            {
                g.DrawLine(p, x1, y1, e.X, e.Y);
                pictureBox1.Image = pic;
            }
            x1 = e.X;
            y1 = e.Y;
        }
    }
}
